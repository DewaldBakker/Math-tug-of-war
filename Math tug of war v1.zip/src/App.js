import './App.css';
import Names from  './Components/Names/Names.jsx'
import Game from './Components/Game/Game.jsx';
import Difficulty from './Components/Difficulty/Difficulty.jsx';
function App() {
  return (
    
    <div>
      <Game/>
    </div>
  );
}

export default App;
