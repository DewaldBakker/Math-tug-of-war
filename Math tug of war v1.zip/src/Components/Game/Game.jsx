import React, { useState, useEffect } from "react";
import "./Game.css";

function Game() {
  const [input, setInput] = useState("");
  const [input2, setInput2] = useState("");
  const [error, setError] = useState("");
  const [error2, setError2] = useState("");

  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState(null);

  const [position, setPosition] = useState(0);
  const maxSteps = 10;

  const pct = (position / maxSteps) * 10;

  //create the questions
     const generateQuestion = () => {
    let num1 = Math.floor(Math.random() * 201) - 100;
    let num2 = Math.floor(Math.random() * 201) - 100;

    if (num2 === 0) num2 = 1;

    const ops = ["+", "-", "*", "/"];
    const op = ops[Math.floor(Math.random() * ops.length)];

    let correct;

    switch (op) {
      case "+":
        correct = num1 + num2;
        break;
      case "-":
        correct = num1 - num2;
        break;
      case "*":
        correct = num1 * num2;
        break;
      case "/":
        correct = num1;
        setQuestion(`${num1 * num2} / ${num2}`);
        setAnswer(correct);
        return;
    }

    setQuestion(`${num1} ${op} (${num2})`);
    setAnswer(correct);
  };

  useEffect(() => {
    generateQuestion();
  }, []);

  // to calculate and to read the players input
  const handleClick = (v) => {
    setError("");
    if (v === "-" && input.length > 0) return;
    setInput((p) => p + v);
  };

  const handleCalculate = () => {
    if (Number(input) === Number(answer)) {
      setPosition((p) => Math.max(p - 1, -maxSteps));
      generateQuestion();
      setInput("");
      setInput2("");
    } else setError("Wrong");
       setInput("");
  };

    // to calculate and to read the players input
  const handleClick2 = (v) => {
    setError2("");
    if (v === "-" && input2.length > 0) return;
    setInput2((p) => p + v);
  };

  const handleCalculate2 = () => {
    if (Number(input2) === Number(answer)) {
      setPosition((p) => Math.min(p + 1, maxSteps));
      generateQuestion();
      setInput("");
      setInput2("");
    } else setError2("Wrong");
      setInput2("");
  };

  return (
    <div className="container">
      <h1 className="question">{question}</h1>

      {/* TUG OF WAR */}
      <div className="tug-wrapper">
        <div
          className="tug-container"
          style={{
            transform: `translateX(${pct}%)`,
          }}
        >
          <img src="/Images/team-a-character.png" className="player" />

          <div className="rope" />

          <img src="/Images/team-b-character.png" className="player" />
        </div>

        <div className="center-line"></div>
      </div>


      <div className="Game">
        <div className="calculator">
          <h2>Participant 1</h2>
          <input value={input} readOnly />
          {error && <p className="error">{error}</p>}

          <div className="buttons">
            {["-","1","2","3","4","5","6","7","8","9","0","="].map((b) => (
              <button onClick={() => b==="="?handleCalculate():handleClick(b)}>
                {b}
              </button>
            ))}
          </div>
        </div>

        <div className="calculator">
          <h2>Participant 2</h2>
          <input value={input2} readOnly />
          {error2 && <p className="error">{error2}</p>}

          <div className="buttons">
            {["-","1","2","3","4","5","6","7","8","9","0","="].map((b) => (
              <button onClick={() => b==="="?handleCalculate2():handleClick2(b)}>
                {b}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Game;