import React, { useState } from "react";

function Names() {
  const [text1, setText1] = useState("");
  const [text2, setText2] = useState("");
  const [message, setMessage] = useState("");

  const handleChange1 = (event) => {
    setText1(event.target.value);
  };
  const handleChange2 = (event) => {
    setText2(event.target.value);
  };
  const Dif=()=>{
    if ((text1==='')||(text2==='') ) {
        setMessage('Please enter names')
    }
  };

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h1>Enter names for the two participants</h1>

      <input
        type="text"
        value={text1}
        onChange={handleChange1}
        placeholder="Name"
        className="Par1"
        style={{
          padding: "8px",
          fontSize: "16px",
          width: "250px",
          border: "1px solid #ccc",
          borderRadius: "4px"
        }}
      />
      <input
        type="text"
        value={text2}
        onChange={handleChange2}
        placeholder="Name"
        className="Par2"
        style={{
          padding: "8px",
          fontSize: "16px",
          width: "250px",
          border: "1px solid #ccc",
          borderRadius: "4px"
        }}
      />
      <div><button className='Dif' onClick={Dif} style={{
          padding: "8px",
          fontSize: "16px",
          width: "250px",
          border: "1px solid #ccc",
          borderRadius: "4px"}}>Choose difficulty</button></div>
      <h1 className="Message">{message}</h1>
      </div>
  );
  
}

export default Names