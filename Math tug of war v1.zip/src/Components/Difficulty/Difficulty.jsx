import React, { useState } from "react";

function Difficulty() {

  const [selectedOption, setSelectedOption] = useState("");


  const options = [
    { value: "Grade 1", label: "Grade 1" },
    { value: "Grade 2", label: "Grade 2" },
    { value: "Grade 3", label: "Grade 3" },
    { value: "Grade 4", label: "Grade 4" },
    { value: "Grade 5", label: "Grade 5" },
    { value: "Grade 6", label: "Grade 6" },
    { value: "Grade 7", label: "Grade 7" },
    { value: "Grade 8", label: "Grade 8" },
    { value: "Grade 9", label: "Grade 9" },
    { value: "Grade 10", label: "Grade 10" },
    { value: "Grade 11", label: "Grade 11" },
    { value: "Grade 12", label: "Grade 12" }
  ];


  const handleChange = (event) => {
    setSelectedOption(event.target.value);
  };


  const handleSubmit = (event) => {
    event.preventDefault();
    if (!selectedOption) {
      alert("Please select an option before submitting.");
    } else {
      alert(`You selected: ${selectedOption}`);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <label htmlFor="fruit-select">Choose a difficulty: </label>
      <select
        id="fruit-select"
        value={selectedOption}
        onChange={handleChange}
      >
        <option value="" disabled>
    -- Select Grade --
        </option>
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>

      <button type="submit" style={{ marginLeft: "10px" }}>
        Submit
      </button>
    </form>
  );
}

export default Difficulty;
