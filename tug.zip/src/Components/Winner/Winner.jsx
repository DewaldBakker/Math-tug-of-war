import React from 'react'
import { useLocation, useNavigate } from "react-router-dom";
import '../Styles/Styles.css'
function Winner() {
  const location = useLocation();
  const navigate = useNavigate();

  const winner = location.state?.winner || "Champion";
  const score = location.state?.score || 0;

  const saveToFile = () => {
    const data = `
Winner: ${winner}
Score: ${score}
Player 1: ${location.state?.name1}
Player 2: ${location.state?.name2}
Difficulty: ${location.state?.difficulty}
`;

    const blob = new Blob([data], { type: "text/plain" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = "game_result.txt";
    a.click();

    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <h1 style={{fontSize:'5rem',fontWeight:'bold', color: '#ff9800'}}>WINNER</h1>

      <h2 style={{fontSize:'5rem',fontWeight:'bold', color: '#ff9800'}}>{winner}</h2>

      <button
        onClick={() =>
          navigate("/game", {
            state: {
              name1: location.state?.name1,
              name2: location.state?.name2,
              difficulty: location.state?.difficulty
            }
          })
        }
        style={{ marginLeft: "10px",marginTop:'10px',fontSize:'1.2rem',fontWeight:'bold' }}
      >
        Rematch
      </button>

      <button onClick={() => navigate("/")} style={{ marginLeft: "10px",marginTop:'10px',fontSize:'1.2rem',fontWeight:'bold' }}>
        New Game
      </button>


      <button onClick={saveToFile} style={{ marginLeft: "10px",marginTop:'10px',fontSize:'1.2rem',fontWeight:'bold' }}>
        Save Result
      </button>
    </div>
  )
}

export default Winner;