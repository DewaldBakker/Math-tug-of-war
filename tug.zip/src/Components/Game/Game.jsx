import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import "./Game.css";

function Game() {
  const navigate = useNavigate();
  const location = useLocation();

  const name1 = location.state?.name1 || "Player 1";
  const name2 = location.state?.name2 || "Player 2";
  const difficulty = location.state?.difficulty || "Easy";

  const [input, setInput] = useState("");
  const [input2, setInput2] = useState("");
  const [error, setError] = useState("");
  const [error2, setError2] = useState("");

  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState(null);

  const [position, setPosition] = useState(0);
  const [score1, setScore1] = useState(0);
  const [score2, setScore2] = useState(0);

  const maxSteps = 6;
  const stepSize = 40;
  const translateX = position * stepSize;

  const getRange = () => {
    switch (difficulty) {
      case "Easy":
        return { min: 0, max: 100 };
      case "Medium":
        return { min: 0, max: 1000 };
      case "Hard":
        return { min: -1000, max: 1000 };
      default:
        return { min: 0, max: 100 };
    }
  };

  const randomInRange = (min, max) =>
    Math.floor(Math.random() * (max - min + 1)) + min;

  const generateQuestion = () => {
    const { min, max } = getRange();

    let num1 = randomInRange(min, max);
    let num2 = randomInRange(min, max);

    if (num2 === 0) num2 = 1;

    let ops;
    if (difficulty === "Easy") {
      ops = ["+", "-"];
    } else if (difficulty === "Medium") {
      ops = ["+", "-", "*"];
    } else {
      ops = ["+", "-", "*", "/"];
    }

    const op = ops[Math.floor(Math.random() * ops.length)];
    let correct;

    if (op === "/") {
      num1 = randomInRange(1, 10);
      num2 = randomInRange(1, 10);
      const product = num1 * num2;
      setQuestion(`${product} / ${num2}`);
      setAnswer(num1);
      return;
    }

    if (op === "-" && difficulty === "Easy" && num2 > num1) {
      [num1, num2] = [num2, num1];
    }

    switch (op) {
      case "+":
        correct = num1 + num2;
        break;
      case "-":
        correct = num1 - num2;
        break;
      case "*":
        correct = num1 * num2;
        break;
      default:
        break;
    }

    setQuestion(`${num1} ${op} ${num2}`);
    setAnswer(correct);
  };

  useEffect(() => {
    generateQuestion();
  }, []);

  useEffect(() => {
    if (position >= maxSteps) {
      navigate("/winner", {
        state: { winner: name2, score: score2, name1, name2, difficulty }
      });
    } else if (position <= -maxSteps) {
      navigate("/winner", {
        state: { winner: name1, score: score1, name1, name2, difficulty }
      });
    }
  }, [position]);

  // Player 2 keyboard only
  useEffect(() => {
    const handleKey = (e) => {
      if (/^[0-9]$/.test(e.key)) {
        setInput2((p) => p + e.key);
        return;
      }

      if (e.key === "-" && input2.length === 0) {
        setInput2("-");
        return;
      }

      if (e.key === "Backspace") {
        setInput2((p) => p.slice(0, -1));
        return;
      }

      if (e.key === "Enter") {
        handleCalculate2();
      }
    };

    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [input2, answer]);

  const handleClick = (v) => {
    setError("");
    if (v === "-" && input.length > 0) return;
    setInput((p) => p + v);
  };

  const handleCalculate = () => {
    if (Number(input) === Number(answer)) {
      setScore1((s) => s + 1);
      setPosition((p) => Math.max(p - 1, -maxSteps));
      generateQuestion();
      setError("");
    } else {
      setError("Wrong");
    }
    setInput("");
  };

  const handleCalculate2 = () => {
    if (Number(input2) === Number(answer)) {
      setScore2((s) => s + 1);
      setPosition((p) => Math.min(p + 1, maxSteps));
      generateQuestion();
      setError2("");
    } else {
      setError2("Wrong");
    }
    setInput2("");
  };

  return (
    <div className="page">
      <div>
        <h2 className="title">
          How to win?<br />
          Pull the other player image past the red line
        </h2>
      </div>

      <br />

      <div className="container">
        <h1 className="question">{question}</h1>

        <div className="tug-wrapper">
          <div
            className="tug-container"
            style={{ transform: `translateX(${translateX}px)` }}
          >
            <img src="/Images/team-a-character.png" className="player" alt="" />
            <div className="rope" />
            <img src="/Images/team-b-character.png" className="player" alt="" />
          </div>

          <div className="center-line"></div>
        </div>

        <div className="Game">
          <div className="calculator">
            <h2>{name1}</h2>
            <input value={input} readOnly />
            {error && <p className="error">{error}</p>}

            <div className="buttons">
              {["-","1","2","3","4","5","6","7","8","9","0","DEL","="].map((b, i) => (
                <button
                  key={i}
                  onClick={() => {
                    if (b === "=") return handleCalculate();
                    if (b === "DEL") return setInput((p) => p.slice(0, -1));
                    handleClick(b);
                  }}
                >
                  {b}
                </button>
              ))}
            </div>
          </div>

          <div className="calculator">
            <h2>{name2} (Keyboard Only)</h2>
            <input value={input2} readOnly />
            {error2 && <p className="error">{error2}</p>}

            <div className="buttons">
              {["-","1","2","3","4","5","6","7","8","9","0","DEL","="].map((b, i) => (
                <button key={i} disabled>
                  {b}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Game;