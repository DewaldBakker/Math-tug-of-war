import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import './Names.css'
function Names() {
  const [name1, setName1] = useState("");
  const [name2, setName2] = useState("");

  const location = useLocation();
  const navigate = useNavigate();

  const difficulty = location.state?.difficulty || "Easy";

  const handleStart = () => {
    if (!name1 || !name2) {
      alert("Enter both names");
      return;
    }

    navigate("/game", {
      state: {
        name1,
        name2,
        difficulty
      }
    });
  };

  return (
    <div>
      <h2 style={{fontSize:'5rem',fontWeight:'bold', color: '#ff9800'}}>Enter Player Names</h2>

      <input  className='input'
        placeholder="Player 1"
        value={name1}
        onChange={(e) => setName1(e.target.value)}
      />

      <input className='input'
        placeholder="Player 2"
        value={name2}
        onChange={(e) => setName2(e.target.value)}
      />
      <br/>
      <button className="button" onClick={handleStart}>Start Game</button>
    </div>
  );
}

export default Names;