import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; 
import '../Styles/Styles.css'
function Difficulty() {
  const [selectedOption, setSelectedOption] = useState("");
  const navigate = useNavigate();

  const options = [
    { value: "Easy", label: "Easy" },
    { value: "Medium", label: "Medium" },
    { value: "Hard", label: "Hard" },
  ];

  const handleChange = (event) => {
    setSelectedOption(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!selectedOption) {
      alert("Please select an option before submitting.");
    } else {
      navigate("/names", { state: { difficulty: selectedOption } }); 
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{fontSize:'5rem',fontWeight:'bold'}}>
      <label className="label" style={{fontSize:'5rem',fontWeight:'bold', color: '#ff9800'}}>Choose a difficulty: </label>
      <br/>
      <select id="difficulty" value={selectedOption} onChange={handleChange}  style={{fontSize:'3rem',fontWeight:'bold'}}>
        <option value="" disabled> -- Select difficulty -- </option>
        
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
      <br/>
      <button className='button'type="submit" style={{ marginLeft: "10px",marginTop:'10px',fontSize:'2rem',fontWeight:'bold' }}>
        Begins
      </button>
    </form>
  );
}
export default Difficulty;