import React from 'react'
import { useNavigate } from "react-router-dom"; 
import '../Styles/Styles.css'

function Main() {
  const navigate = useNavigate(); 

  return (
    <div>
      <div className="title-section">
        <div className="lightning-bolts">⚡ ⚡ ⚡</div>
        <h1>
          <span className="title-word math">MATH</span>
          <span className="title-word tug">TUG</span>
          <span className="title-word of">OF</span>
          <span className="title-word war">WAR!</span>
        </h1>
        <div className="lightning-bolts">⚡ ⚡ ⚡</div>
      </div>

      <p className="catchphrase">"Brain vs Brain — Pull the Rope with Every Right Answer!"</p>
      <p className="sub-catchphrase">🧠 Quicker mind wins the battle 📚</p>

      <button 
        className="btn play-btn" 
        id="playBtn"
        onClick={() => navigate("/difficulty")}
      >
        🎮 PLAY NOW 🎮
      </button>

    </div>
  )
}
export default Main