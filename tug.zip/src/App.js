mport { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Names from "./Components/Names/Names.jsx"; 
import Game from "./Components/Game/Game.jsx"; 
import Start from "./Components/Main/Main.jsx"; 
import Winner from "./Components/Winner/Winner.jsx"; 
import Difficulty from "./Components/Difficulty/Difficulty.jsx";
import './App.css'
 function App() {
   return ( 
   <div className="gamesize"> 
   <Router> 
    <Routes> 
      <Route path="/" element={<Start />} /> 
      <Route path="/difficulty" element={<Difficulty />} /> 
      <Route path="/names" element={<Names />} /> 
      <Route path="/game" element={<Game />} /> 
      <Route path="/winner" element={<Winner />} /> 
      </Routes> </Router> </div> ); 
    } 
    export default App;